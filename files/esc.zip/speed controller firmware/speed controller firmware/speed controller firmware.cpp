/*
 * speed_controller_firmware.cpp
 *
 * Created: 11/16/2014 2:48:29 PM
 *  Author: William
 */ 


#include <avr/io.h>
#include <avr/interrupt.h>

int main(void)
{
	
	DDRA |= (1<<DDA7);//set port A7 to output (to 'A' MOSFET driver)	//port A1 to input (PWM signal in) is already an input
	DDRB |= (1<<DDB2);//set port B2 to output (to 'B' MOSFET driver)
	DDRA |= (1<<DDA2);//set port A2 to output (to signal LED)
	
	PORTA |= (1<<PORTA0 | 1<<PORTA1 | 1<<PORTA3 | 1<<PORTA4 | 1<<PORTA5 | 1<<PORTA6);//enable pull up resistors on port A to reduce noise
	PORTB |= (1<<PORTB0 | 1<<PORTB1 | 1<<PORTB3);//enable pull up resistors on port B to reduce noise
	
	TCCR0A |= (1<<WGM00); TCCR0A &= ~(1<<WGM01);//set timer 0 to phase-correct PWM mode
	TCCR0B |= (1<<CS11 | 1<<CS10); TCCR0B &= ~(1<<CS12);//set timer 0 prescaler to 8
	TCCR1B &= ~(1<<CS12 | 1<<CS10); TCCR1B |= (1<<CS11);//set timer 1 prescaler to 8
	
	PCMSK0 |= (1<<PCINT1);//enable interrupt on PCINT1 (PWM input pin)
	GIMSK |= (1<<PCIE0);//enable pin change 0 interrupts
	
	TIMSK1 |= (1<<TOIE1);//enable timer 1 overflow interrupt
	
	sei();//enable global interrupts
	
			PORTA &= ~(1<<PORTA7);
			PORTB |= (1<<PORTB2);
    while(1)
    {
        //TODO:: Please write your application code 
    }
}
ISR(PCINT0_vect){//PWM signal edge
	TCCR1B &= ~(1<<CS12 | 1<<CS11 | 1<<CS10);//stop timer 1
	PORTA &= ~(1<<PORTA2);//turn off signal light
	uint16_t pulsewidth = 0;
	uint16_t x = 0;//for calculations
	if(bit_is_set(PINA, PINA1)){//if PWM signal is high
		GTCCR |= (1<<PSR10);//reset prescaler
		TCNT1 = 0;//set timer to zero

	}else{
		pulsewidth = TCNT1;//get timed period since timer 1 was zero, which should be the last time the interrupt was called and the signal was high
		//pulsewidth = 1500;
		if (pulsewidth > 1520){
			x = pulsewidth - 1520;
			x = x / 2;
			if (x > 255){x = 255;
				PORTA |= (1<<PORTA2);}//turn on signal light
			TCCR0A |= (1<<COM0A1 | 1<<COM0A0);//connect timer 0 output compare A to port B2 as PWM output
			OCR0A = x;
		}
		else{
			TCCR0A &= ~(1<<COM0A1 | 1<<COM0A0);//disconnect timer 0 output compare A from port B2
			PORTB |= (1<<PORTB2);
		}
		if (pulsewidth < 1480){
			x = 1480 - pulsewidth;
			x = x / 2;
			if (x > 255){x = 255;
				PORTA |= (1<<PORTA2);}//turn on signal light
			TCCR0A |= (1<<COM0B1 | 1<<COM0B0);//connect timer 0 output compare B to port A7 as PWM output, pin is high when counter is above output compare
			OCR0B = x;
		}
		else{
			TCCR0A &= ~(1<<COM0B1 | 1<<COM0B0);//disconnect timer 0 output compare B from port A7
			PORTA |= (1<<PORTA7);
		}
		if(pulsewidth > 1479 && pulsewidth < 1521){PORTA |= (1<<PORTA2);}//turn on signal light
	}
	TCCR1B &= ~(1<<CS12 | 1<<CS10); TCCR1B |= (1<<CS11);//restart timer 1 by setting it to prescaler 8
}
ISR(TIM1_OVF_vect){
	TCCR0A &= ~(1<<COM0A1 | 1<<COM0A0);//disconnect timer 0 output compare A from port B2
	PORTB |= (1<<PORTB2);//ground output B2
	TCCR0A &= ~(1<<COM0B1 | 1<<COM0B0);//disconnect timer 0 output compare B from port A7
	PORTA |= (1<<PORTA7);//ground output A7
}